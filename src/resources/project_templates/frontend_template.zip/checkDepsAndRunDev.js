const { execSync } = require('child_process');
const fs = require('fs');

try {
    // Verifica si la carpeta node_modules existe
    if (!fs.existsSync('node_modules')) {
        console.log('🔄 node_modules no encontrado. Ejecutando bun install...');
        execSync('bun install', { stdio: 'inherit' });
    }

    // Ejecuta el comando bun run dev
    console.log('🚀 Iniciando el servidor de desarrollo...');
    execSync('rsbuild dev --open --port 9000', { stdio: 'inherit' });
} catch (error) {
    console.error('❌ Ocurrió un error:', error);
    process.exit(1);
}
