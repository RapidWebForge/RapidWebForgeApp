import { defineConfig } from '@rsbuild/core';
import { pluginReact } from '@rsbuild/plugin-react';

export default defineConfig({
  plugins: [pluginReact()],
  source: {
    define: {
      "import.meta.env.API_BASE_URL": JSON.stringify(process.env.API_BASE_URL),
    }
  }
});
