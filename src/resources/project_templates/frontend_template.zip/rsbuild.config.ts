import { defineConfig } from "@rsbuild/core";
import { pluginReact } from "@rsbuild/plugin-react";
// Export the configuration as a default export

export default defineConfig({
  plugins: [pluginReact()],
  source: {
    define: {
      "import.meta.env.API_BASE_URL": JSON.stringify(process.env.API_BASE_URL),
    },
  },
  rules: [
    {
      test: /\.css$/,
      use: [
        {
          loader: "postcss-loader",
          options: {
            postcssOptions: {
              plugins: {
                tailwindcss: {},
                autoprefixer: {},
              },
            },
          },
        },
      ],
      type: "css",
    },
  ],
});
