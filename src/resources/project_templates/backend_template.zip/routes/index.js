const express = require("express");
const router = express.Router();

module.exports = router; // Exporta el enrutador consolidado
